var express = require('express');
var router = express.Router();
const ctrlMain = require('../controllers/main');

const authController = require("../controllers/authentication");
const tripsController = require("../controllers/trips");

/* GET home page. */
router.get('/', ctrlMain.index);
router
  .route("/trips")
  .get(tripsController.tripsList)
  .post(auth, tripsController.tripsAddTrip);

router
  .route("/trips/:tripCode")
  .get(tripsController.tripsList)
  .put(auth, tripsController.tripsUpdateTrip);

module.exports = router;
