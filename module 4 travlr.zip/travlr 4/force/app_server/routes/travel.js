const express = require('express');
const router = express.Router();
const controller= require('../controllers/travel');

var fs = require('fs');
var trips = JSON.parse(fs.readFileSync('./data/trips.json',
'utf8'));


/* GET home page. */
router.get('/', controller.travel);
module.exports = router;